/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';

interface StepGoalProps {
  learningGoal: string;
  setLearningGoal: (goal: string) => void;
  onNext: () => void;
  errorMessage?: string | null;
}

const StepGoal: React.FC<StepGoalProps> = ({ learningGoal, setLearningGoal, onNext, errorMessage }) => {
  return (
    <div>
      <h2>Step 1: What's Your Learning Goal Today?</h2>
      <p>Defining a clear goal helps in creating a focused learning plan.</p>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <label htmlFor="learningGoal">Learning Goal:</label>
      <textarea
        id="learningGoal"
        value={learningGoal}
        onChange={(e) => setLearningGoal(e.target.value)}
        placeholder="e.g., Understand Chapter 5 of Physics, Prepare for a history quiz on WWII, Learn the basics of Python functions"
        rows={3}
        aria-describedby={errorMessage ? "goal-error" : undefined}
        aria-invalid={!!errorMessage}
      />
      {errorMessage && <span id="goal-error" className="sr-only">{errorMessage}</span>}
      <div className="button-group">
        <button onClick={onNext} disabled={!learningGoal.trim()}>Next</button>
      </div>
    </div>
  );
};

export default StepGoal;