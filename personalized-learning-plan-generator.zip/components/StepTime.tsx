/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';

interface StepTimeProps {
  totalTime: number;
  setTotalTime: (time: number) => void;
  onNext: () => void; // This will trigger plan generation
  onBack: () => void;
  errorMessage?: string | null;
}

const StepTime: React.FC<StepTimeProps> = ({ totalTime, setTotalTime, onNext, onBack, errorMessage }) => {
  return (
    <div>
      <h2>Step 4: How Much Time Do You Have?</h2>
      <p>Enter your total available study time in minutes.</p>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <label htmlFor="totalTime">Total Study Time (minutes):</label>
      <input
        type="number"
        id="totalTime"
        value={totalTime}
        onChange={(e) => setTotalTime(parseInt(e.target.value, 10) || 0)}
        min="10"
        placeholder="e.g., 60"
        aria-describedby={errorMessage ? "time-error" : undefined}
        aria-invalid={!!errorMessage}
      />
      {errorMessage && <span id="time-error" className="sr-only">{errorMessage}</span>}
      <div className="button-group">
        <button onClick={onBack} className="secondary">Back</button>
        <button onClick={onNext} disabled={totalTime < 10}>Generate Plan</button>
      </div>
    </div>
  );
};

export default StepTime;