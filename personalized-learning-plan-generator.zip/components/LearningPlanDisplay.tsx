/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';
import type { LearningPlanItem, PlanGenerationError } from '../lib/types';
import LoadingSpinner from './LoadingSpinner';

interface LearningPlanDisplayProps {
  learningPlan: LearningPlanItem[] | null;
  planError: PlanGenerationError | null;
  onStart: () => void;
  onBack: () => void; // Go back to time/topic selection
  onEditTopics: () => void;
  isLoading: boolean;
}

const LearningPlanDisplay: React.FC<LearningPlanDisplayProps> = ({
  learningPlan,
  planError,
  onStart,
  onBack,
  onEditTopics,
  isLoading
}) => {
  if (isLoading) {
    return <LoadingSpinner message="Generating your learning plan..." />;
  }

  if (planError) {
    return (
      <div className="plan-display">
        <h2>Learning Plan Error</h2>
        <p className="error-message">{planError.error}</p>
        {planError.suggestedFocus && planError.suggestedFocus.length > 0 && (
          <div>
            <p>Suggested focus for the given time:</p>
            <ul>
              {planError.suggestedFocus.map((topic, index) => (
                <li key={index}>{topic}</li>
              ))}
            </ul>
          </div>
        )}
        <div className="button-group">
          <button onClick={onEditTopics} className="secondary">Edit Topics</button>
          <button onClick={onBack} className="secondary">Adjust Time</button>
        </div>
      </div>
    );
  }

  if (!learningPlan || learningPlan.length === 0) {
    return (
      <div className="plan-display">
        <h2>Learning Plan</h2>
        <p>No learning plan generated. This might be due to an unexpected issue or if no topics could be processed.</p>
        <div className="button-group">
          <button onClick={onEditTopics} className="secondary">Edit Topics</button>
           <button onClick={onBack} className="secondary">Adjust Time</button>
        </div>
      </div>
    );
  }
  
  const totalDuration = learningPlan.reduce((sum, item) => sum + item.durationMinutes, 0);

  return (
    <div className="plan-display">
      <h2>Your Personalized Learning Plan</h2>
      <p>Here's a plan to help you achieve your goal. Total estimated time: <strong>{totalDuration} minutes</strong>.</p>
      <ul>
        {learningPlan.map((item, index) => (
          <li key={index} className={item.type === 'break' ? 'break-item' : 'study-item'}>
            <strong>{item.taskName}</strong> ({item.durationMinutes} minutes)
          </li>
        ))}
      </ul>
      <div className="button-group">
        <button onClick={onBack} className="secondary">Back (Edit Time/Plan)</button>
        <button onClick={onStart}>Start Learning Session</button>
      </div>
    </div>
  );
};

export default LearningPlanDisplay;