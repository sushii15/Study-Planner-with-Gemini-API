/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { LearningPlanItem } from '../lib/types';
import { Play, Pause, SkipForward, RotateCcw, CheckCircle, Coffee } from 'lucide-react';


interface PomodoroTimerProps {
  learningPlan: LearningPlanItem[];
  onSessionEnd: () => void;
}

const PomodoroTimer: React.FC<PomodoroTimerProps> = ({ learningPlan, onSessionEnd }) => {
  const [currentTaskIndex, setCurrentTaskIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0); // in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentTask = learningPlan[currentTaskIndex];

  const setupCurrentTask = useCallback(() => {
    if (currentTaskIndex >= learningPlan.length) {
      onSessionEnd();
      return;
    }
    const task = learningPlan[currentTaskIndex];
    setTimeLeft(task.durationMinutes * 60);
    setIsBreak(task.type === 'break');
    setIsTimerRunning(false); // Pause timer when new task starts
  }, [currentTaskIndex, learningPlan, onSessionEnd]);

  useEffect(() => {
    setupCurrentTask();
  }, [currentTaskIndex, setupCurrentTask]);

  useEffect(() => {
    if (!isTimerRunning || timeLeft <= 0) {
      if (isTimerRunning && timeLeft <= 0) { // Timer just finished
        if (audioRef.current) {
          audioRef.current.play().catch(e => console.warn("Audio play failed:", e));
        }
        handleSkipTask(); // Automatically move to next task/break
      }
      return;
    }

    const timerId = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1);
    }, 1000);

    return () => clearInterval(timerId);
  }, [isTimerRunning, timeLeft]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartPause = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const handleResetTimer = () => {
    setupCurrentTask(); // Resets to current task's full duration
  };

  const handleSkipTask = () => {
    if (currentTaskIndex < learningPlan.length - 1) {
      setCurrentTaskIndex(currentTaskIndex + 1);
    } else {
      onSessionEnd();
    }
  };

  if (!currentTask) {
    return (
      <div className="pomodoro-timer">
        <h2>Session Complete!</h2>
        <p>Well done! You've completed your learning plan.</p>
        <button onClick={onSessionEnd}>Plan Another Session</button>
      </div>
    );
  }
  
  // Simple Base64 encoded beep sound for notification
  const beepSound = "data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU"+
                    "LlvT19AgADc2ZmZgYJCwsMDQ4PEBESExQVFhcYGRobHB0eHyAhIiMkJSYnKCkqKywtLi8wMTIzNDU2"+
                    "Nzg5Ojs8PT4/QEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaW1xdXl9gYWJjZGVmZ2hpamtsbW5vcHFy"+
                    "c3R1dnd4eXp7fH1+f4CBgoOEhYaHiImKi4yNjo+QkZKTlJWWl5iZmpucnZ6foKGio6SlpqeoqaqrrK2u"+
                    "r7CxsrO0tba3uLm6u7y9vr/AwcLDxMXGx8jJysvMzc7P0NHS09TV1tfY2drb3N3e3+Dh4uPk5ebn6Onq"+
                    "6+zt7u/w8fLz9PX29/j5+vv8/f7/AAAA//8=";


  return (
    <div className="pomodoro-timer">
      <audio ref={audioRef} src={beepSound} preload="auto" />
      <h2>{isBreak ? "Break Time!" : "Focus Time!"}</h2>
      <div className="current-task">
        {isBreak ? <Coffee size={24} style={{ marginRight: '8px', verticalAlign: 'middle' }} /> : <CheckCircle size={24} style={{ marginRight: '8px', verticalAlign: 'middle' }} />}
        Current: {currentTask.taskName}
      </div>
      <div className="timer-display" aria-live="polite">
        {formatTime(timeLeft)}
      </div>
      <div className="timer-controls button-group" style={{flexDirection: 'row', justifyContent: 'center', gap: '0.5rem', flexWrap: 'wrap'}}>
        <button onClick={handleStartPause} aria-label={isTimerRunning ? "Pause timer" : "Start timer"}>
          {isTimerRunning ? <Pause /> : <Play />} {isTimerRunning ? 'Pause' : 'Start'}
        </button>
        <button onClick={handleResetTimer} className="secondary" aria-label="Reset timer for current task">
           <RotateCcw /> Reset
        </button>
        <button onClick={handleSkipTask} className="secondary" aria-label="Skip to next task or break">
           <SkipForward /> Skip
        </button>
      </div>
       <p style={{marginTop: '1.5rem', fontSize: '0.9em', color: 'var(--muted-text-color)'}}>
        Task {currentTaskIndex + 1} of {learningPlan.length}
      </p>
      <button onClick={onSessionEnd} className="secondary" style={{marginTop: '2rem'}}>End Session & View Summary</button>
    </div>
  );
};

export default PomodoroTimer;