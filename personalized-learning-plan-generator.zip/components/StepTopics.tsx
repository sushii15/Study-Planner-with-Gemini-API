/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useRef } from 'react';
import LoadingSpinner from './LoadingSpinner';


interface StepTopicsProps {
  topicsText: string;
  setTopicsText: (text: string) => void;
  onImageUpload: (file: File) => void;
  imagePreview: string | null;
  onNext: () => void;
  onBack: () => void;
  isLoading: boolean;
  errorMessage?: string | null;
}

const StepTopics: React.FC<StepTopicsProps> = ({
  topicsText,
  setTopicsText,
  onImageUpload,
  imagePreview,
  onNext,
  onBack,
  isLoading,
  errorMessage
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  return (
    <div>
      <h2>Step 3: What Topics Will You Cover?</h2>
      <p>Enter topics comma-separated, or upload an image of your syllabus.</p>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      
      <label htmlFor="topicsText">Topics (comma-separated):</label>
      <textarea
        id="topicsText"
        value={topicsText}
        onChange={(e) => setTopicsText(e.target.value)}
        placeholder="e.g., Newton's Laws, The Cold War, Data Types & Variables"
        rows={4}
        disabled={isLoading}
      />

      <label htmlFor="syllabusImage">Or Upload Syllabus Image:</label>
      <input
        type="file"
        id="syllabusImage"
        accept="image/*"
        onChange={handleFileChange}
        ref={fileInputRef}
        aria-label="Upload syllabus image"
        disabled={isLoading}
      />
      {isLoading && <LoadingSpinner message="Processing syllabus image..." />}
      {imagePreview && !isLoading && (
        <div>
          <p>Syllabus Preview:</p>
          <img src={imagePreview} alt="Syllabus preview" className="image-preview" />
        </div>
      )}
      
      <div className="button-group">
        <button onClick={onBack} className="secondary" disabled={isLoading}>Back</button>
        <button onClick={onNext} disabled={isLoading || (!topicsText.trim() && !imagePreview)}>Next</button>
      </div>
    </div>
  );
};

export default StepTopics;