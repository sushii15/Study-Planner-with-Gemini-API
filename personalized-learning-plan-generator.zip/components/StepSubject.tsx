/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';

interface StepSubjectProps {
  subject: string;
  setSubject: (subject: string) => void;
  onNext: () => void;
  onBack: () => void;
  errorMessage?: string | null;
}

const StepSubject: React.FC<StepSubjectProps> = ({ subject, setSubject, onNext, onBack, errorMessage }) => {
  return (
    <div>
      <h2>Step 2: What Subject Are You Studying?</h2>
      <p>This helps tailor the plan more specifically.</p>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <label htmlFor="subject">Subject:</label>
      <input
        type="text"
        id="subject"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        placeholder="e.g., Physics, History, Python Programming"
        aria-describedby={errorMessage ? "subject-error" : undefined}
        aria-invalid={!!errorMessage}
      />
      {errorMessage && <span id="subject-error" className="sr-only">{errorMessage}</span>}
      <div className="button-group">
        <button onClick={onBack} className="secondary">Back</button>
        <button onClick={onNext} disabled={!subject.trim()}>Next</button>
      </div>
    </div>
  );
};

export default StepSubject;