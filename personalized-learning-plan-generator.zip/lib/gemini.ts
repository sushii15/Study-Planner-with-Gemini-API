/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, GenerateContentResponse, Part } from '@google/genai';
import type { LearningPlanItem, PlanGenerationError } from './types';

// API key must be obtained exclusively from process.env.API_KEY
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY is not set in environment variables.");
  // In a real app, you might want to display this error to the user or disable API features.
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Non-null assertion as we check above

const TEXT_MODEL_NAME = 'gemini-2.5-flash-preview-04-17'; // For text and plan generation
const MULTIMODAL_MODEL_NAME = 'gemini-2.5-flash-preview-04-17'; // For image processing

/**
 * Extracts topics from a base64 encoded syllabus image.
 * @param base64ImageData The base64 encoded image data (without the 'data:image/...;base64,' prefix).
 * @returns A promise that resolves to a comma-separated string of topics.
 */
export async function extractTopicsFromImageAPI(base64ImageData: string): Promise<string> {
  if (!API_KEY) throw new Error("API Key not configured.");
  try {
    const imagePart: Part = {
      inlineData: {
        mimeType: 'image/png', // Assuming PNG, adjust if other types are common
        data: base64ImageData,
      },
    };
    const textPart: Part = {
      text: "Extract the list of topics from this syllabus image. Provide the topics as a comma-separated string. Focus on main topics and sub-topics. If no topics are clearly discernible, return an empty string.",
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: MULTIMODAL_MODEL_NAME,
        contents: { parts: [textPart, imagePart] }, // Order can matter, text prompt first
    });

    // console.log("Syllabus extraction full response:", JSON.stringify(response, null, 2));
    const extractedText = response.text;
    // console.log("Extracted text from syllabus:", extractedText);
    return extractedText.trim();

  } catch (error) {
    console.error('Error extracting topics from image via API:', error);
    throw new Error(`Failed to extract topics from image. ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Generates a learning plan based on user inputs.
 * @param learningGoal The user's learning goal.
 * @param subject The subject of study.
 * @param topics The list of topics (comma-separated string).
 * @param totalTimeMinutes The total available study time in minutes.
 * @returns A promise that resolves to an array of LearningPlanItem objects or a PlanGenerationError.
 */
export async function generateLearningPlanAPI(
  learningGoal: string,
  subject: string,
  topics: string,
  totalTimeMinutes: number
): Promise<LearningPlanItem[] | PlanGenerationError> {
  if (!API_KEY) throw new Error("API Key not configured.");
  const prompt = `
    You are an expert instructional designer. Create a personalized learning plan.
    Goal: ${learningGoal}
    Subject: ${subject}
    Topics to cover: ${topics}
    Total available time: ${totalTimeMinutes} minutes.

    Your task is to:
    1.  Break down the topics into manageable study chunks. If a topic is large, it can be split.
    2.  Allocate time to each topic chunk in minutes. Minimum study chunk should be 10 minutes.
    3.  Incorporate short breaks (5-10 minutes) between study sessions. Aim for a Pomodoro-like structure (e.g., 20-30 minutes study, 5 minute break).
    4.  Ensure the total time (study + breaks) fits within the user's specified total available time. Adjust chunk/break durations if necessary.
    5.  If the topics are too extensive for the given time, even after trying to make reasonable chunks, you MUST respond with a JSON object detailing the error and suggesting a focus.
        The error JSON should be: { "error": "The topics are too extensive for the allocated time. Please reduce the number of topics or increase the study time.", "suggestedFocus": ["First topic to focus on", "Second topic to focus on"] } (suggestedFocus can be an empty array if no specific suggestion can be made).
    6.  Otherwise, the output MUST be a JSON array of objects, where each object represents a task or a break. Each object must have:
        *   "type": "study" or "break" (string)
        *   "taskName": string (e.g., "Introduction to Photosynthesis", "Short Break")
        *   "durationMinutes": number (integer)

    Example of successful JSON output:
    [
      { "type": "study", "taskName": "Topic A - Part 1", "durationMinutes": 25 },
      { "type": "break", "taskName": "Short Break", "durationMinutes": 5 },
      { "type": "study", "taskName": "Topic A - Part 2", "durationMinutes": 20 },
      { "type": "study", "taskName": "Topic B - Overview", "durationMinutes": 25 },
      { "type": "break", "taskName": "Short Break", "durationMinutes": 5 }
    ]

    Ensure the response is ONLY the JSON object or array, with no other text or markdown.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: TEXT_MODEL_NAME,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            // Optional: Add thinkingConfig if needed for this model, but typically not for plan generation.
            // thinkingConfig: { thinkingBudget: 0 } // Disable thinking for low latency if applicable. Default is enabled.
        },
    });
    
    // console.log("Learning plan generation full response:", JSON.stringify(response, null, 2));
    let jsonStr = response.text.trim();
    // console.log("Raw plan generation text:", jsonStr);

    // The model might still wrap the JSON in ```json ... ```
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr);
    
    // Validate the parsed data structure
    if (Array.isArray(parsedData)) {
        // Basic validation for LearningPlanItem array
        if (parsedData.every(item => 
            typeof item.type === 'string' && (item.type === 'study' || item.type === 'break') &&
            typeof item.taskName === 'string' &&
            typeof item.durationMinutes === 'number' && item.durationMinutes > 0
        )) {
            return parsedData as LearningPlanItem[];
        } else {
            throw new Error("Generated plan items have incorrect structure.");
        }
    } else if (parsedData && typeof parsedData.error === 'string') {
        return parsedData as PlanGenerationError;
    } else {
        throw new Error("Unexpected JSON structure received from API.");
    }

  } catch (error) {
    console.error('Error generating learning plan via API:', error);
    // Try to parse if it's a known Gemini error structure, otherwise rethrow generic
    if (error instanceof Error && error.message.includes("SAFETY")) {
         throw new Error(`Plan generation failed due to safety settings. Please rephrase your topics or goal. ${error.message}`);
    }
    if (error instanceof Error && error.message.includes("resourceExhausted")) {
         throw new Error(`API quota exceeded or resource unavailable. Please try again later. ${error.message}`);
    }
    throw new Error(`Failed to generate learning plan. ${error instanceof Error ? error.message : String(error)}`);
  }
}