/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LearningPlanItem {
  type: 'study' | 'break';
  taskName: string;
  durationMinutes: number;
}

export interface PlanGenerationError {
  error: string;
  suggestedFocus?: string[];
}
